require 'pry'

class Player
	attr_reader :name, :player_value
  
  def initialize(name,player_value)
    #TO DO : doit régler son nom et sa valeur
    @name = name
    @player_value = player_value
  end

end

